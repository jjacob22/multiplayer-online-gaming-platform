# SENG 300 Project Group 3

### Profile Authentication
| Name                      | UCID     |
|---------------------------|----------|
| Srijita Marick            | 30230880 |
| Anna Littkemann           | 30212220 |
| Phone Myat Paing          | 30221105 |
| Hoang Duong               | 30226332 |
| Jacob Situ                | 30144935 |

### Game Logic
| Name                      | UCID     |
|---------------------------|----------|
| Amy Wiebe                 | 30212853 |
| Mamadou Cellou Diallo     | 30191307 |
| Parker Gueth              | 30207744 |
| Mahdiyar Ashrafioun       | 30232243 |

### GUI
| Name                      | UCID       |
|---------------------------|------------|
| Divya Sree Lakshmi Gude   | 30203095   |
| Justice Olson             | 30211124   |
| Nathan Welch              | 30231941   |
| Kostiantyn Ilnytskyi      | 30235641   |
| Christopher Umukoro       | 30228900   |

### Networking
| Name                      | UCID     |
|---------------------------|----------|
| Rojina Dayhimi            | 30232355 |
| Owen Hills                | 30209974 |
| Saw Daniel Aung Khant Moe | 30227027 |
| Dhruv Pujara              | 30210700 |
| Henis Patel               | 30212728 |
| Elina Pachhai             | 30175227 |

### Leaderboard & Matchmaking
| Name                      | UCID       |
|---------------------------|------------|
| Martin Webster            | 30227712   |
| Vanja Salkauskas          | 30142154   |
| Cole Runions-Kahler       | 30102473   |
| Minh Vu                   | 30104789   |

### Ex-members
| Name                      | UCID       |
|---------------------------|------------|
| Billy Kreuger             | 30193923   |