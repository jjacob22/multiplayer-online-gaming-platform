package match_making;

public class Match {
    protected final int MATCHID;
    int player1ID;
    int player2ID;

    public Match(int matchID) {
        MATCHID = matchID;
    }
}
