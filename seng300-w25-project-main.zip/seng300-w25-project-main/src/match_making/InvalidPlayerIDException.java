package match_making;

public class InvalidPlayerIDException extends RuntimeException {
    public InvalidPlayerIDException(String message) {
        super(message);
    }
}
