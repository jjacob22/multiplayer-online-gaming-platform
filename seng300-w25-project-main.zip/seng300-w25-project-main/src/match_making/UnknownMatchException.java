package match_making;

public class UnknownMatchException extends RuntimeException {
    public UnknownMatchException(String message) {
        super(message);
    }
}
