package networking;

public abstract class AbstractNetworkManager {

    public void connect() {

    }


    public void disconnect() {

    }






}






