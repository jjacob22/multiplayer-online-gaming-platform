package networking.requestMessages;

import java.io.Serializable;

public record GetBio() implements Serializable {
}
