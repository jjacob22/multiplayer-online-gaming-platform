package networking.requestMessages;

import java.io.Serializable;

public record GetFriendRequests() implements Serializable {
}
