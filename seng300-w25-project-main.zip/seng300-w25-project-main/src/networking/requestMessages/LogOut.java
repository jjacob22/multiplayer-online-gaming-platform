package networking.requestMessages;

import java.io.Serializable;

/**
 * A record object for logging out
 */
public record LogOut() implements Serializable {
}
