package networking.requestMessages;

import java.io.Serializable;

public record RequestOnlinePlayers() implements Serializable {
}
