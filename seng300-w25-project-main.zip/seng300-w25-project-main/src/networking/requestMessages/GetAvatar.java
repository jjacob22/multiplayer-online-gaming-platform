package networking.requestMessages;

import java.io.Serializable;

public record GetAvatar() implements Serializable {
}
