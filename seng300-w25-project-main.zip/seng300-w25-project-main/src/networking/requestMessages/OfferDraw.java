package networking.requestMessages;

import java.io.Serializable;


public record OfferDraw() implements Serializable {
}
