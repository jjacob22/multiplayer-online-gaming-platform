package networking.requestMessages;

import java.io.Serializable;

public record GetFriends() implements Serializable {
}
