package networking.requestMessages;

import java.io.Serializable;

public record GetBlockedUsers() implements Serializable {
}
