package networking.responseMessages;

public interface Response {
}
