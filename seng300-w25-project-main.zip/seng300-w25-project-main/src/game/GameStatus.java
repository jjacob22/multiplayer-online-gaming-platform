package game;

import java.io.Serializable;

public enum GameStatus implements Serializable {
    PLAYING, WIN, DRAW
}
